# Equipo Michelle Navia - Cristian Olivares

App Mini ToDo con Rutas

- Se crearon rutas con React Router para las distintas paginas
- Formulario para ingreso de tareas
- Tabla renderización de tareas
- Manejo de localStorage
- UseEffect

## Compotentes
- Task
- NewTask
## Páginas
 - Home
 - NewTask
 - Task