
function Home() {
  return (
    <>
      <h1>Bienvenido a mis tareas</h1>
    </>
  );
}

export { Home };